import React from "react";
import './App.css';
import MiApi from "./components/MiApi";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <>
      <h1>Personajes de Harry Potter</h1>
      <MiApi />
      <footer>
        Todos los derechos reservados <br />@ValentinaElisa
      </footer>
    </>
  );
}

export default App;
