import React from 'react';

const Buscador = ({ onCasaChange, onOrdenChange, todasLasCasas }) => {
  const handleCasaChange = (event) => {
    onCasaChange(event.target.value);
  };

  const handleOrdenChange = (event) => {
    onOrdenChange(event.target.value);
  };

  return (
    <form className="Opciones" onSubmit={(e) => e.preventDefault()}>
      <div className="mb-3">
        <select className="form-select" id="casa" onChange={handleCasaChange}>
          <option value="">Todas las casas</option>
          {todasLasCasas.map((casa, index) => (
            <option key={index} value={casa}>{casa}</option>
          ))}
        </select>
      </div>

      <div className="mb-3">
        <select className="form-select" id="orden" onChange={handleOrdenChange}>
          <option value="">Ordenar por:</option>
          <option value="nombre">Nombre</option>
          <option value="casa">Casa</option>
        </select>
      </div>
    </form>
  );
};

export default Buscador;