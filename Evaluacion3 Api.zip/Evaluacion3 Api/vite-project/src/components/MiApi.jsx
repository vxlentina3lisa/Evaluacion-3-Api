import React, { useState, useEffect } from "react";
import axios from "axios";
import { Card, Container } from "react-bootstrap";
import Buscador from "./Buscador";

const MiApi = () => {
  const [personajesData, setPersonajesData] = useState([]);
  const [personajesFiltrados, setPersonajesFiltrados] = useState([]);
  const [todasLasCasas, setTodasLasCasas] = useState([]);
  const [orden, setOrden] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("https://hp-api.onrender.com/api/characters");
        const personajesValidos = response.data.filter(personaje => personaje.name && personaje.house && personaje.image);
        setPersonajesData(personajesValidos);
        setPersonajesFiltrados(personajesValidos);
        setTodasLasCasas([...new Set(personajesValidos.map(p => p.house))]);
      } catch (error) {
      }
    };

    fetchData();
  }, []);

  const handleCasaChange = (casaSeleccionada) => {
    const filtrados = casaSeleccionada ? personajesData.filter(personaje => personaje.house === casaSeleccionada) : personajesData;
    setPersonajesFiltrados(filtrados);
  };

  const handleOrdenChange = (ordenSeleccionado) => {
    setOrden(ordenSeleccionado);
    let ordenados = [...personajesFiltrados];
    if (ordenSeleccionado === "nombre") {
      ordenados.sort((a, b) => a.name.localeCompare(b.name));
    } else if (ordenSeleccionado === "casa") {
      ordenados.sort((a, b) => a.house.localeCompare(b.house));
    }
    setPersonajesFiltrados(ordenados);
  };

  return (
    <Container>
      <Buscador
        onCasaChange={handleCasaChange}
        onOrdenChange={handleOrdenChange}
        todasLasCasas={todasLasCasas}
      />
      <div className="mt-5 d-flex justify-content-center gap-3 cardContainer">
        {personajesFiltrados.map((personaje, index) => (
          <Card key={index} className="personajeCard">
            <Card.Img variant="top" src={personaje.image} />
            <Card.Body>
              <Card.Title>{personaje.name}</Card.Title>
              <Card.Text>
                <strong>Casa:</strong> {personaje.house}
                <br />
              </Card.Text>
            </Card.Body>
          </Card>
        ))}
      </div>
    </Container>
  );
};

export default MiApi;